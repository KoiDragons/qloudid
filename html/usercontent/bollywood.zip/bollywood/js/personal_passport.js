﻿

$(function() {

var fileName='personal_passport.php?v=1';
  var t ={	"View More": {
      sv: "Visa mer"
    },
    
    "Translate to English": {
      sv: "Översätt till engelska"
    },
    "Translate to Swedish": {
      sv: "Översätt till svenska"
    },
	"Sign in as": {
      sv: "Logga in som"
    },
	"Logout": {
      sv: "Logga ut"
    },
	"Personal": {
      sv: "Personlig"
    },
	"newsfeed": {
      sv: "nyhetsflöde"
    },
	"Newsfeed": {
      sv: "Nyhetsflöde"
    },
	
	"News": {
      sv: "Nyheter"
    },
	"View": {
      sv: "Visa"
    },
	"More": {
      sv: "mer"
    },
	"User": {
      sv: "Användare"
    },
	"Passport": {
      sv: "Pass"
    },
	"Change Password": {
      sv: "Ändra lösenord"
    },
	"Request connection": {
      sv: "Begär anslutning"
    },
	"Add your company": {
      sv: "Lägg till ditt företag"
    },
	"Social Security Number": {
      sv: "Personnummer"
    },
	"Family name": {
      sv: "Efternamn"
    },
	"Given names": {
      sv: "Givna namn"
    },
	"Address": {
      sv: "Adress"
    },
	"Date of birth": {
      sv: "Födelsedatum"
    },
	"Sex": {
      sv: "Sex"
    },
	"Endorsements": {
      sv: "påskrifter"
    },
	"Date of Exp": {
      sv: "Datum för Exp"
    },
	"Restrictions": {
      sv: "begränsningar"
    },
	"Classification": {
      sv: "klassificeringar"
    },
	"Date of issue": {
      sv: "Utgivningsdatum"
    },
	"Update Image": {
      sv: "Uppdatera bild"
    },
	"Veteran": {
      sv: "Veteran"
    },
	"Landlord": {
      sv: "Hyresvärd"
    },
	"Employer": {
      sv: "Arbetsgivare"
    },
	"School": {
      sv: "Skola"
    },
	"My carrier": {
      sv: "Min karriär"
    },
    
  };
 
 
 
 var _t = $('body').translate({lang: langVar, t: t});
  var str = _t.g("translate");

  $(".lang_selector").click(function(ev) {
    var lang = $(this).attr("data-value");
    _t.lang(lang);

    console.log(lang);
    ev.preventDefault();
  });



});



    
    
